import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  orderBy, 
  limit, 
  onSnapshot,
  increment,
  runTransaction,
  setDoc,
  Timestamp
} from 'firebase/firestore';
import { db, auth } from '../firebase';
import { Question, Answer, Vote, Category, User, DoubtComment, Notification, Bookmark } from '../types';

// Notifications
export const getNotifications = (userId: string) => {
  return query(
    collection(db, 'notifications'),
    where('userId', '==', userId),
    orderBy('createdAt', 'desc'),
    limit(20)
  );
};

export const markNotificationRead = async (id: string) => {
  await updateDoc(doc(db, 'notifications', id), { read: true });
};

const createNotification = async (userId: string, type: string, message: string, link: string) => {
  if (userId === auth.currentUser?.uid) return; // Don't notify self
  await addDoc(collection(db, 'notifications'), {
    userId,
    type,
    message,
    link,
    read: false,
    createdAt: new Date().toISOString()
  });
};

// Comments
export const getComments = (targetId: string) => {
  return query(
    collection(db, 'comments'),
    where('targetId', '==', targetId),
    orderBy('createdAt', 'asc')
  );
};

export const createComment = async (data: Partial<DoubtComment>) => {
  const commentRef = await addDoc(collection(db, 'comments'), {
    ...data,
    createdAt: new Date().toISOString()
  });

  // Notify target author
  const targetRef = doc(db, data.targetType === 'question' ? 'questions' : 'answers', data.targetId!);
  const targetSnap = await getDoc(targetRef);
  if (targetSnap.exists()) {
    const targetData = targetSnap.data();
    await createNotification(
      targetData.authorId,
      'comment',
      `${data.authorName} commented on your ${data.targetType}`,
      data.targetType === 'question' ? `/questions/${data.targetId}` : `/questions/${targetData.questionId}`
    );
  }
  return commentRef;
};

// Bookmarks
export const toggleBookmark = async (userId: string, questionId: string) => {
  const bookmarkId = `${userId}_${questionId}`;
  const bookmarkRef = doc(db, 'bookmarks', bookmarkId);
  const bookmarkSnap = await getDoc(bookmarkRef);

  if (bookmarkSnap.exists()) {
    await deleteDoc(bookmarkRef);
    return false;
  } else {
    await setDoc(bookmarkRef, {
      userId,
      questionId,
      createdAt: new Date().toISOString()
    });
    return true;
  }
};

export const getBookmarks = (userId: string) => {
  return query(collection(db, 'bookmarks'), where('userId', '==', userId));
};

// Reputation & Badges Logic
const updateReputationAndLevel = async (transaction: any, userRef: any, amount: number) => {
  const userSnap = await transaction.get(userRef);
  if (!userSnap.exists()) return;
  
  const userData = userSnap.data() as User;
  const newRep = (userData.reputation || 0) + amount;
  
  let newLevel = userData.level || 'Beginner';
  if (newRep >= 1000) newLevel = 'Expert';
  else if (newRep >= 100) newLevel = 'Pro';

  const newBadges = [...(userData.badges || [])];
  if (newRep >= 100 && !newBadges.includes('100 Upvotes Club')) {
    newBadges.push('100 Upvotes Club');
  }

  transaction.update(userRef, { 
    reputation: newRep,
    level: newLevel,
    badges: newBadges
  });
};

// Categories
export const getCategories = async (): Promise<Category[]> => {
  const snapshot = await getDocs(collection(db, 'categories'));
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Category));
};

// Questions
export const getQuestions = (categoryId?: string, sortBy: 'newest' | 'top' = 'newest', authorId?: string) => {
  let q = query(collection(db, 'questions'));
  
  if (categoryId) {
    q = query(q, where('categoryId', '==', categoryId));
  }

  if (authorId) {
    q = query(q, where('authorId', '==', authorId));
  }
  
  if (sortBy === 'newest') {
    q = query(q, orderBy('createdAt', 'desc'));
  } else {
    q = query(q, orderBy('voteCount', 'desc'), orderBy('createdAt', 'desc'));
  }
  
  return q;
};

export const getQuestion = async (id: string): Promise<Question | null> => {
  const docRef = doc(db, 'questions', id);
  const docSnap = await getDoc(docRef);
  if (docSnap.exists()) {
    return { id: docSnap.id, ...docSnap.data() } as Question;
  }
  return null;
};

export const createQuestion = async (data: Partial<Question>) => {
  return await addDoc(collection(db, 'questions'), {
    ...data,
    views: 0,
    voteCount: 0,
    answerCount: 0,
    isResolved: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  });
};

export const incrementViews = async (id: string) => {
  const docRef = doc(db, 'questions', id);
  await updateDoc(docRef, { views: increment(1) });
};

// Answers
export const getAnswers = (questionId?: string, authorId?: string) => {
  let q = query(collection(db, 'answers'));
  
  if (questionId) {
    q = query(q, where('questionId', '==', questionId));
  }

  if (authorId) {
    q = query(q, where('authorId', '==', authorId));
  }

  q = query(q, orderBy('isAccepted', 'desc'), orderBy('voteCount', 'desc'), orderBy('createdAt', 'asc'));
  
  return q;
};

export const createAnswer = async (data: Partial<Answer>) => {
  return await runTransaction(db, async (transaction) => {
    const questionRef = doc(db, 'questions', data.questionId!);
    const answerRef = doc(collection(db, 'answers'));
    const questionSnap = await transaction.get(questionRef);
    
    transaction.set(answerRef, {
      ...data,
      isAccepted: false,
      voteCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
    
    transaction.update(questionRef, { answerCount: increment(1) });

    // Notify question author
    if (questionSnap.exists()) {
      const qData = questionSnap.data();
      await createNotification(
        qData.authorId,
        'answer',
        `${data.authorName} answered your question`,
        `/questions/${data.questionId}`
      );
    }

    return answerRef;
  });
};

export const acceptAnswer = async (questionId: string, answerId: string, authorId: string) => {
  return await runTransaction(db, async (transaction) => {
    const questionRef = doc(db, 'questions', questionId);
    const answerRef = doc(db, 'answers', answerId);
    const authorRef = doc(db, 'users', authorId);
    
    transaction.update(questionRef, { isResolved: true });
    transaction.update(answerRef, { isAccepted: true });
    await updateReputationAndLevel(transaction, authorRef, 25);

    await createNotification(
      authorId,
      'accepted',
      `Your answer was accepted!`,
      `/questions/${questionId}`
    );
  });
};

// Voting
export const vote = async (userId: string, targetId: string, targetType: 'question' | 'answer', value: number, targetAuthorId: string) => {
  const voteId = `${userId}_${targetId}`;
  const voteRef = doc(db, 'votes', voteId);
  const targetRef = doc(db, targetType === 'question' ? 'questions' : 'answers', targetId);
  const authorRef = doc(db, 'users', targetAuthorId);
  
  return await runTransaction(db, async (transaction) => {
    const voteSnap = await transaction.get(voteRef);
    const repAmount = targetType === 'question' ? 10 : 15;
    
    if (voteSnap.exists()) {
      const oldVote = voteSnap.data() as Vote;
      if (oldVote.value === value) {
        // Remove vote
        transaction.delete(voteRef);
        transaction.update(targetRef, { voteCount: increment(-value) });
        await updateReputationAndLevel(transaction, authorRef, -repAmount * value);
      } else {
        // Change vote
        transaction.update(voteRef, { value, createdAt: new Date().toISOString() });
        transaction.update(targetRef, { voteCount: increment(2 * value) });
        await updateReputationAndLevel(transaction, authorRef, 2 * repAmount * value);
      }
    } else {
      // New vote
      transaction.set(voteRef, {
        userId,
        targetId,
        targetType,
        value,
        createdAt: new Date().toISOString()
      });
      transaction.update(targetRef, { voteCount: increment(value) });
      await updateReputationAndLevel(transaction, authorRef, repAmount * value);

      if (value === 1) {
        await createNotification(
          targetAuthorId,
          'vote',
          `Someone upvoted your ${targetType}`,
          targetType === 'question' ? `/questions/${targetId}` : `/questions/${targetId}`
        );
      }
    }
  });
};
