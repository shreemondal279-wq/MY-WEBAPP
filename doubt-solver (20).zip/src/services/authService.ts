import { 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged, 
  User as FirebaseUser 
} from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  setDoc, 
  serverTimestamp 
} from 'firebase/firestore';
import { auth, db, googleProvider } from '../firebase';
import { User } from '../types';

export const loginWithGoogle = async () => {
  const result = await signInWithPopup(auth, googleProvider);
  const user = result.user;
  
  // Create user profile if it doesn't exist
  const userRef = doc(db, 'users', user.uid);
  const userDoc = await getDoc(userRef);
  
  if (!userDoc.exists()) {
    const newUser: User = {
      uid: user.uid,
      email: user.email || '',
      username: user.displayName || 'Anonymous',
      avatarUrl: user.photoURL || undefined,
      reputation: 0,
      level: 'Beginner',
      badges: [],
      createdAt: new Date().toISOString()
    };
    await setDoc(userRef, newUser);
  }
  return user;
};

export const logout = () => signOut(auth);

export const subscribeToAuth = (callback: (user: FirebaseUser | null) => void) => {
  return onAuthStateChanged(auth, callback);
};

export const getUserProfile = async (uid: string): Promise<User | null> => {
  const userRef = doc(db, 'users', uid);
  const userDoc = await getDoc(userRef);
  return userDoc.exists() ? (userDoc.data() as User) : null;
};
