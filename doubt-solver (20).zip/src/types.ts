export interface User {
  uid: string;
  email: string;
  username: string;
  avatarUrl?: string;
  bio?: string;
  reputation: number;
  level: 'Beginner' | 'Pro' | 'Expert';
  badges: string[];
  createdAt: string;
}

export interface DoubtComment {
  id: string;
  body: string;
  authorId: string;
  authorName: string;
  targetId: string;
  targetType: 'question' | 'answer';
  createdAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  type: 'answer' | 'vote' | 'comment' | 'accepted';
  message: string;
  link: string;
  read: boolean;
  createdAt: string;
}

export interface Bookmark {
  id: string;
  userId: string;
  questionId: string;
  createdAt: string;
}

export interface Question {
  id: string;
  title: string;
  body: string;
  categoryId: string;
  authorId: string;
  authorName: string;
  views: number;
  voteCount: number;
  answerCount: number;
  isResolved: boolean;
  tags: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Answer {
  id: string;
  questionId: string;
  questionTitle?: string;
  questionAuthorId?: string;
  body: string;
  authorId: string;
  authorName: string;
  isAccepted: boolean;
  voteCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface Vote {
  id: string;
  userId: string;
  targetId: string;
  targetType: 'question' | 'answer';
  value: number;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  color: string;
  icon: string;
  description?: string;
}
