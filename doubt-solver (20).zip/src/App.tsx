import React, { useState, useEffect } from 'react';
import { 
  BrowserRouter as Router, 
  Routes, 
  Route, 
  Link, 
  useNavigate, 
  useParams, 
  useSearchParams 
} from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  Plus, 
  User as UserIcon, 
  LogOut, 
  Menu, 
  X, 
  MessageSquare, 
  ThumbsUp, 
  ThumbsDown, 
  Eye, 
  CheckCircle, 
  Clock, 
  ChevronRight,
  BookOpen,
  Code,
  Globe,
  FlaskConical,
  History as HistoryIcon,
  Languages,
  TrendingUp,
  Share2,
  Flag,
  Edit,
  Trash2,
  Bell,
  Bookmark as BookmarkIcon,
  Mic,
  Moon,
  Sun,
  Award,
  Zap,
  Star
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { onSnapshot, collection, doc, setDoc, getDocs, query, where, orderBy, limit, addDoc } from 'firebase/firestore';
import { auth, db } from './firebase';
import { subscribeToAuth, loginWithGoogle, logout, getUserProfile } from './services/authService';
import { 
  getQuestions, 
  getQuestion, 
  createQuestion, 
  getAnswers, 
  createAnswer, 
  acceptAnswer, 
  vote, 
  getCategories,
  incrementViews,
  getNotifications,
  markNotificationRead,
  getComments,
  createComment,
  toggleBookmark,
  getBookmarks
} from './services/dataService';
import { User, Question, Answer, Category, Vote, DoubtComment, Bookmark } from './types';
import { cn, formatRelativeTime } from './lib/utils';

// --- Components ---

const Button = ({ className, variant = 'primary', size = 'md', ...props }: any) => {
  const variants: any = {
    primary: 'bg-indigo-600 text-white hover:bg-indigo-700',
    secondary: 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50',
    ghost: 'bg-transparent text-gray-600 hover:bg-gray-100',
    danger: 'bg-red-600 text-white hover:bg-red-700',
  };
  const sizes: any = {
    sm: 'px-3 py-1.5 text-sm',
    md: 'px-4 py-2',
    lg: 'px-6 py-3 text-lg',
  };
  return (
    <button 
      className={cn('inline-flex items-center justify-center rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed', variants[variant], sizes[size], className)} 
      {...props} 
    />
  );
};

const Card = ({ className, children }: any) => (
  <div className={cn('bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden', className)}>
    {children}
  </div>
);

const Badge = ({ children, color = 'gray' }: any) => {
  const colors: any = {
    blue: 'bg-blue-50 text-blue-700 border-blue-100',
    green: 'bg-green-50 text-green-700 border-green-100',
    purple: 'bg-purple-50 text-purple-700 border-purple-100',
    amber: 'bg-amber-50 text-amber-700 border-amber-100',
    pink: 'bg-pink-50 text-pink-700 border-pink-100',
    teal: 'bg-teal-50 text-teal-700 border-teal-100',
    orange: 'bg-orange-50 text-orange-700 border-orange-100',
    gray: 'bg-gray-50 text-gray-700 border-gray-100',
  };
  return (
    <span className={cn('px-2 py-0.5 text-xs font-medium border rounded-full', colors[color])}>
      {children}
    </span>
  );
};

const Avatar = ({ src, name, size = 'md' }: any) => {
  const sizes: any = {
    sm: 'w-6 h-6 text-[10px]',
    md: 'w-10 h-10 text-sm',
    lg: 'w-16 h-16 text-xl',
  };
  const initials = name ? name.split(' ').map((n: string) => n[0]).join('').toUpperCase().slice(0, 2) : '?';
  
  if (src) {
    return <img src={src} alt={name} className={cn('rounded-full object-cover', sizes[size])} referrerPolicy="no-referrer" />;
  }
  return (
    <div className={cn('rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold', sizes[size])}>
      {initials}
    </div>
  );
};

// --- Layout ---

const NotificationDropdown = ({ userId, onClose }: any) => {
  const [notifications, setNotifications] = useState<any[]>([]);

  useEffect(() => {
    const unsubscribe = onSnapshot(getNotifications(userId), (snapshot) => {
      setNotifications(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return () => unsubscribe();
  }, [userId]);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 10 }}
      className="absolute right-0 mt-2 w-80 bg-white border border-gray-200 rounded-xl shadow-xl z-50 overflow-hidden"
    >
      <div className="p-4 border-b border-gray-100 flex justify-between items-center">
        <h3 className="font-bold text-gray-900">Notifications</h3>
        <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X className="w-4 h-4" /></button>
      </div>
      <div className="max-h-96 overflow-y-auto">
        {notifications.length > 0 ? (
          notifications.map(n => (
            <Link 
              key={n.id} 
              to={n.link} 
              onClick={() => { markNotificationRead(n.id); onClose(); }}
              className={cn('block p-4 hover:bg-gray-50 border-b border-gray-50 last:border-0 transition-colors', !n.read && 'bg-indigo-50/30')}
            >
              <p className="text-sm text-gray-800">{n.message}</p>
              <p className="text-[10px] text-gray-400 mt-1">{formatRelativeTime(n.createdAt)}</p>
            </Link>
          ))
        ) : (
          <div className="p-8 text-center text-gray-400 text-sm">No notifications yet</div>
        )}
      </div>
    </motion.div>
  );
};

const Navbar = ({ user, onLogin, onLogout, theme, onToggleTheme }: any) => {
  const [search, setSearch] = useState('');
  const [showNotifications, setShowNotifications] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [profile, setProfile] = useState<User | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      getUserProfile(user.uid).then(setProfile);
    }
  }, [user]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (search.trim()) {
      navigate(`/?q=${encodeURIComponent(search)}`);
    }
  };

  return (
    <nav className={cn('sticky top-0 z-50 border-b transition-colors', theme === 'dark' ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-gray-200')}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
            <div className="flex items-center gap-8">
              <Link to="/" className="flex items-center gap-2">
                <motion.div 
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-500/20"
                >
                  <BookOpen className="w-5 h-5 text-white" />
                </motion.div>
                <span className={cn('text-xl font-bold hidden sm:block', theme === 'dark' ? 'text-white' : 'text-gray-900')}>Doubt Solver</span>
              </Link>

              <div className="hidden md:flex items-center gap-6">
                <Link to="/" className={cn('text-sm font-medium transition-colors', theme === 'dark' ? 'text-zinc-400 hover:text-white' : 'text-gray-600 hover:text-indigo-600')}>Questions</Link>
                <Link to="/subjects" className={cn('text-sm font-medium transition-colors', theme === 'dark' ? 'text-zinc-400 hover:text-white' : 'text-gray-600 hover:text-indigo-600')}>Subjects</Link>
              </div>

              <form onSubmit={handleSearch} className="relative hidden md:block w-64 lg:w-96">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input 
                type="text" 
                placeholder="Search questions..." 
                className={cn(
                  'w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all',
                  theme === 'dark' ? 'bg-zinc-800 border-zinc-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
                )}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </form>
          </div>

          <div className="flex items-center gap-4">
            <button onClick={onToggleTheme} className="p-2 text-gray-400 hover:text-indigo-600 transition-colors">
              {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>

            <button onClick={() => setShowMobileMenu(!showMobileMenu)} className="md:hidden p-2 text-gray-400 hover:text-indigo-600 transition-colors">
              {showMobileMenu ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>

            {user ? (
              <div className="flex items-center gap-4">
                <div className="relative">
                  <button onClick={() => setShowNotifications(!showNotifications)} className="p-2 text-gray-400 hover:text-indigo-600 transition-colors relative">
                    <Bell className="w-5 h-5" />
                    <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white" />
                  </button>
                  <AnimatePresence>
                    {showNotifications && <NotificationDropdown userId={user.uid} onClose={() => setShowNotifications(false)} />}
                  </AnimatePresence>
                </div>

                <Link to="/ask">
                  <Button size="sm" className="hidden sm:flex gap-2 shadow-lg shadow-indigo-500/20">
                    <Plus className="w-4 h-4" /> Ask Question
                  </Button>
                </Link>
                
                <div className="flex items-center gap-3 pl-4 border-l border-gray-200">
                  <Link to={`/users/${user.uid}`} className="flex items-center gap-2 hover:opacity-80 transition-opacity">
                    <Avatar src={user.photoURL} name={user.displayName} size="sm" />
                    <div className="hidden lg:block text-left">
                      <p className={cn('text-xs font-semibold leading-none', theme === 'dark' ? 'text-white' : 'text-gray-900')}>{user.displayName}</p>
                      <div className="flex items-center gap-1 mt-1">
                        <Badge color="blue" className="text-[8px] px-1 py-0">{profile?.level || 'Beginner'}</Badge>
                        <span className="text-[10px] text-gray-500">{profile?.reputation || 0} pts</span>
                      </div>
                    </div>
                  </Link>
                  <Button variant="ghost" size="sm" onClick={onLogout} className="p-2">
                    <LogOut className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ) : (
              <Button onClick={onLogin} className="gap-2">
                <UserIcon className="w-4 h-4" /> Sign In
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {showMobileMenu && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className={cn('md:hidden border-t overflow-hidden', theme === 'dark' ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-gray-100')}
          >
            <div className="px-4 py-6 space-y-4">
              <form onSubmit={handleSearch} className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input 
                  type="text" 
                  placeholder="Search questions..." 
                  className={cn(
                    'w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500',
                    theme === 'dark' ? 'bg-zinc-800 border-zinc-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
                  )}
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </form>
              <div className="grid grid-cols-2 gap-4">
                <Link 
                  to="/" 
                  onClick={() => setShowMobileMenu(false)}
                  className={cn('flex items-center justify-center p-4 rounded-xl border text-sm font-bold', theme === 'dark' ? 'bg-zinc-800 border-zinc-700 text-white' : 'bg-gray-50 border-gray-100 text-gray-900')}
                >
                  Questions
                </Link>
                <Link 
                  to="/subjects" 
                  onClick={() => setShowMobileMenu(false)}
                  className={cn('flex items-center justify-center p-4 rounded-xl border text-sm font-bold', theme === 'dark' ? 'bg-zinc-800 border-zinc-700 text-white' : 'bg-gray-50 border-gray-100 text-gray-900')}
                >
                  Subjects
                </Link>
              </div>
              {user && (
                <Link to="/ask" onClick={() => setShowMobileMenu(false)}>
                  <Button className="w-full gap-2">
                    <Plus className="w-4 h-4" /> Ask Question
                  </Button>
                </Link>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Sidebar = ({ categories, selectedCategory, onSelect, theme }: any) => {
  return (
    <div className="w-64 hidden lg:block pr-8">
      <div className="space-y-1">
        <p className={cn('text-xs font-semibold uppercase tracking-wider mb-4 px-3', theme === 'dark' ? 'text-zinc-500' : 'text-gray-400')}>Subjects</p>
        <button 
          onClick={() => onSelect(null)}
          className={cn(
            'w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors',
            !selectedCategory 
              ? (theme === 'dark' ? 'bg-indigo-900/40 text-indigo-400' : 'bg-indigo-50 text-indigo-700') 
              : theme === 'dark' ? 'text-zinc-400 hover:bg-zinc-800' : 'text-gray-600 hover:bg-gray-50'
          )}
        >
          <Globe className="w-4 h-4" /> All Subjects
        </button>
        {categories.map((cat: Category) => (
          <button 
            key={cat.id}
            onClick={() => onSelect(cat.id)}
            className={cn(
              'w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors',
              selectedCategory === cat.id 
                ? (theme === 'dark' ? 'bg-indigo-900/40 text-indigo-400' : 'bg-indigo-50 text-indigo-700') 
                : theme === 'dark' ? 'text-zinc-400 hover:bg-zinc-800' : 'text-gray-600 hover:bg-gray-50'
            )}
          >
            <span className={cn('w-2 h-2 rounded-full', `bg-${cat.color}-500`)} />
            {cat.name}
          </button>
        ))}
      </div>

      <div className="mt-12">
        <DailyChallenge theme={theme} />
      </div>
    </div>
  );
};

const TrendingSection = ({ questions, theme }: { questions: Question[], theme: string }) => {
  const trending = [...questions].sort((a, b) => (b.views + b.voteCount * 2) - (a.views + a.voteCount * 2)).slice(0, 5);

  return (
    <div className={cn('p-6 rounded-2xl border', theme === 'dark' ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-gray-100')}>
      <h3 className={cn('font-bold mb-4 flex items-center gap-2', theme === 'dark' ? 'text-white' : 'text-gray-900')}>
        <TrendingUp className="w-4 h-4 text-orange-500" /> Trending
      </h3>
      <div className="space-y-4">
        {trending.map((q, i) => (
          <Link key={q.id} to={`/questions/${q.id}`} className="group block">
            <div className="flex gap-3">
              <span className="text-lg font-black text-gray-200 group-hover:text-indigo-200 transition-colors">0{i + 1}</span>
              <div>
                <h4 className={cn('text-sm font-bold line-clamp-2 group-hover:text-indigo-600 transition-colors', theme === 'dark' ? 'text-gray-200' : 'text-gray-800')}>
                  {q.title}
                </h4>
                <div className="flex items-center gap-2 mt-1 text-[10px] text-gray-400">
                  <span>{q.answerCount} answers</span>
                  <span>•</span>
                  <span>{q.views} views</span>
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

const DailyChallenge = ({ theme }: { theme: string }) => {
  return (
    <div className={cn('p-6 rounded-2xl border relative overflow-hidden', theme === 'dark' ? 'bg-indigo-900/20 border-indigo-500/30' : 'bg-indigo-600 border-indigo-600')}>
      <div className="relative z-10">
        <div className="flex items-center gap-2 mb-2">
          <Zap className="w-4 h-4 text-yellow-400 fill-current" />
          <span className="text-[10px] font-bold text-indigo-200 uppercase tracking-widest">Daily Challenge</span>
        </div>
        <h4 className="text-white font-bold mb-3 leading-tight text-sm">Solve today's math puzzle and earn +50 rep!</h4>
        <Button variant="secondary" size="sm" className="w-full text-[10px] font-bold h-8">Start Challenge</Button>
      </div>
      <div className="absolute -right-4 -bottom-4 w-24 h-24 bg-white/10 rounded-full blur-2xl" />
    </div>
  );
};

// --- Pages ---

const Home = ({ user, theme }: any) => {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<'newest' | 'top'>('newest');
  const [searchParams, setSearchParams] = useSearchParams();
  const queryParam = searchParams.get('q');
  const categoryParam = searchParams.get('category');

  useEffect(() => {
    const fetchCategories = async () => {
      const cats = await getCategories();
      setCategories(cats);
    };
    fetchCategories();
  }, []);

  useEffect(() => {
    if (categoryParam) {
      setSelectedCategory(categoryParam);
    }
  }, [categoryParam]);

  useEffect(() => {
    const q = getQuestions(selectedCategory || undefined, sortBy);
    const unsubscribe = onSnapshot(q, (snapshot) => {
      let data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Question));
      if (queryParam) {
        const term = queryParam.toLowerCase();
        data = data.filter(q => q.title.toLowerCase().includes(term) || q.body.toLowerCase().includes(term));
      }
      setQuestions(data);
    });
    return () => unsubscribe();
  }, [selectedCategory, sortBy, queryParam]);

  const handleCategorySelect = (id: string | null) => {
    setSelectedCategory(id);
    if (id) {
      setSearchParams({ category: id });
    } else {
      setSearchParams({});
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Mobile Category Selector */}
      <div className="lg:hidden mb-8 overflow-x-auto pb-2 scrollbar-hide">
        <div className="flex gap-2 whitespace-nowrap">
          <button 
            onClick={() => handleCategorySelect(null)}
            className={cn(
              'px-4 py-2 rounded-full text-xs font-bold transition-all border',
              !selectedCategory 
                ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-500/20' 
                : theme === 'dark' ? 'bg-zinc-900 border-zinc-800 text-zinc-400' : 'bg-white border-gray-200 text-gray-600'
            )}
          >
            All Subjects
          </button>
          {categories.map(cat => (
            <button 
              key={cat.id}
              onClick={() => handleCategorySelect(cat.id)}
              className={cn(
                'px-4 py-2 rounded-full text-xs font-bold transition-all border',
                selectedCategory === cat.id 
                  ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-500/20' 
                  : theme === 'dark' ? 'bg-zinc-900 border-zinc-800 text-zinc-400' : 'bg-white border-gray-200 text-gray-600'
              )}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      <div className="flex gap-8">
        <Sidebar 
          categories={categories} 
          selectedCategory={selectedCategory} 
          onSelect={handleCategorySelect} 
          theme={theme}
        />
        
        <div className="flex-1">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
            <div>
              <h1 className={cn('text-2xl font-bold', theme === 'dark' ? 'text-white' : 'text-gray-900')}>
                {queryParam ? `Search results for "${queryParam}"` : 'Recent Questions'}
              </h1>
              <p className="text-sm text-gray-500 mt-1">{questions.length} questions found</p>
            </div>
            
            <div className={cn('flex items-center p-1 rounded-lg', theme === 'dark' ? 'bg-zinc-900' : 'bg-gray-100')}>
              <button 
                onClick={() => setSortBy('newest')}
                className={cn('px-4 py-1.5 text-sm font-medium rounded-md transition-all', sortBy === 'newest' ? (theme === 'dark' ? 'bg-zinc-800 text-white shadow-sm' : 'bg-white shadow-sm text-gray-900') : 'text-gray-500 hover:text-gray-700')}
              >
                Newest
              </button>
              <button 
                onClick={() => setSortBy('top')}
                className={cn('px-4 py-1.5 text-sm font-medium rounded-md transition-all', sortBy === 'top' ? (theme === 'dark' ? 'bg-zinc-800 text-white shadow-sm' : 'bg-white shadow-sm text-gray-900') : 'text-gray-500 hover:text-gray-700')}
              >
                Top Voted
              </button>
            </div>
          </div>

          <div className="space-y-4">
            {questions.length > 0 ? (
              <AnimatePresence mode="popLayout">
                {questions.map(q => (
                  <QuestionCard key={q.id} question={q} categories={categories} theme={theme} />
                ))}
              </AnimatePresence>
            ) : (
              <div className={cn('text-center py-20 rounded-xl border border-dashed', theme === 'dark' ? 'bg-zinc-900 border-zinc-800' : 'bg-gray-50 border-gray-300')}>
                <MessageSquare className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <h3 className={cn('text-lg font-medium', theme === 'dark' ? 'text-white' : 'text-gray-900')}>No questions found</h3>
                <p className="text-gray-500 mt-1">Be the first to ask a question in this category!</p>
                <Link to="/ask" className="mt-6 inline-block">
                  <Button>Ask a Question</Button>
                </Link>
              </div>
            )}
          </div>
        </div>

        <div className="w-72 hidden xl:block">
          <TrendingSection questions={questions} theme={theme} />
        </div>
      </div>
    </div>
  );
};

const QuestionCard = ({ question, categories, theme }: { question: Question, categories: Category[], theme: string }) => {
  const category = categories.find(c => c.id === question.categoryId);
  
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
    >
      <Card className={cn('hover:border-indigo-200 transition-colors', theme === 'dark' ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-gray-100')}>
        <div className="p-6 flex gap-6">
          <div className="flex flex-col items-center gap-4 text-center hidden sm:flex">
            <div className={cn('p-3 rounded-lg min-w-[64px]', theme === 'dark' ? 'bg-zinc-800' : 'bg-gray-50')}>
              <p className={cn('text-lg font-bold leading-none', theme === 'dark' ? 'text-white' : 'text-gray-900')}>{question.voteCount}</p>
              <p className="text-[10px] uppercase tracking-wider text-gray-500 mt-1">Votes</p>
            </div>
            <div className={cn('p-3 rounded-lg min-w-[64px]', question.answerCount > 0 ? (theme === 'dark' ? 'bg-green-900/20 text-green-400 border border-green-900/30' : 'bg-green-50 text-green-700 border border-green-100') : (theme === 'dark' ? 'bg-zinc-800 border border-zinc-700' : 'bg-white border border-gray-100'))}>
              <p className="text-lg font-bold leading-none">{question.answerCount}</p>
              <p className="text-[10px] uppercase tracking-wider mt-1">Answers</p>
            </div>
          </div>

          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              {category && <Badge color={category.color}>{category.name}</Badge>}
              <span className="text-xs text-gray-400">•</span>
              <span className="text-xs text-gray-400 flex items-center gap-1">
                <Clock className="w-3 h-3" /> {formatRelativeTime(question.createdAt)}
              </span>
            </div>
            
            <Link to={`/questions/${question.id}`} className="block group">
              <h3 className={cn('text-lg font-bold group-hover:text-indigo-600 transition-colors line-clamp-2', theme === 'dark' ? 'text-white' : 'text-gray-900')}>
                {question.title}
              </h3>
            </Link>
            
            <div className="mt-3 flex flex-wrap gap-2">
              {question.tags.map(tag => (
                <span key={tag} className="text-xs text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">#{tag}</span>
              ))}
            </div>

            <div className="mt-6 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Avatar name={question.authorName} size="sm" />
                <span className={cn('text-sm font-medium', theme === 'dark' ? 'text-zinc-400' : 'text-gray-700')}>{question.authorName}</span>
              </div>
              
              <div className="flex items-center gap-4 text-gray-400">
                <span className="flex items-center gap-1 text-xs"><Eye className="w-4 h-4" /> {question.views}</span>
                <span className="flex items-center gap-1 text-xs sm:hidden"><ThumbsUp className="w-4 h-4" /> {question.voteCount}</span>
                <span className="flex items-center gap-1 text-xs sm:hidden"><MessageSquare className="w-4 h-4" /> {question.answerCount}</span>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </motion.div>
  );
};

const QuestionDetail = ({ user, theme }: any) => {
  const { id } = useParams();
  const [question, setQuestion] = useState<Question | null>(null);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [comments, setComments] = useState<Record<string, DoubtComment[]>>({});
  const [newAnswer, setNewAnswer] = useState('');
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [loading, setLoading] = useState(true);
  const [categories, setCategories] = useState<Category[]>([]);

  useEffect(() => {
    if (!id) return;
    
    const fetchData = async () => {
      const q = await getQuestion(id);
      if (q) {
        setQuestion(q);
        incrementViews(id);
      }
      const cats = await getCategories();
      setCategories(cats);
      setLoading(false);
    };
    
    fetchData();

    const unsubscribe = onSnapshot(getAnswers(id), async (snapshot) => {
      const answersData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Answer));
      setAnswers(answersData);
      
      // Fetch comments for each answer
      for (const ans of answersData) {
        const comsQuery = getComments(ans.id);
        const comsSnap = await getDocs(comsQuery);
        const coms = comsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as DoubtComment));
        setComments(prev => ({ ...prev, [ans.id]: coms }));
      }
    });

    // Fetch comments for the question itself
    const fetchQComments = async () => {
      const comsQuery = getComments(id);
      const comsSnap = await getDocs(comsQuery);
      const coms = comsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as DoubtComment));
      setComments(prev => ({ ...prev, [id]: coms }));
    };
    fetchQComments();

    if (user) {
      const fetchBookmarks = async () => {
        const bmsQuery = getBookmarks(user.uid);
        const bmsSnap = await getDocs(bmsQuery);
        const bms = bmsSnap.docs.map(doc => (doc.data() as Bookmark).questionId);
        setIsBookmarked(bms.includes(id));
      };
      fetchBookmarks();
    }

    return () => unsubscribe();
  }, [id, user]);

  const handlePostAnswer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !id || !newAnswer.trim()) return;

    await createAnswer({
      questionId: id,
      body: newAnswer,
      authorId: user.uid,
      authorName: user.displayName,
      questionTitle: question?.title || '',
      questionAuthorId: question?.authorId || '',
    });
    setNewAnswer('');
  };

  const handleVote = async (targetId: string, targetType: 'question' | 'answer', val: number, targetAuthorId: string) => {
    if (!user) {
      alert('Please sign in to vote');
      return;
    }
    await vote(user.uid, targetId, targetType, val, targetAuthorId);
  };

  const handleAccept = async (answerId: string, authorId: string) => {
    if (!id || !question || user?.uid !== question.authorId) return;
    await acceptAnswer(id, answerId, authorId);
  };

  const handleBookmark = async () => {
    if (!user || !id) return;
    const active = await toggleBookmark(user.uid, id);
    setIsBookmarked(active);
  };

  const handleComment = async (targetId: string, body: string) => {
    if (!user) return;
    await createComment({
      targetId,
      body,
      authorId: user.uid,
      authorName: user.displayName,
    });
    const comsQuery = getComments(targetId);
    const comsSnap = await getDocs(comsQuery);
    const coms = comsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as DoubtComment));
    setComments(prev => ({ ...prev, [targetId]: coms }));
  };

  if (loading) return <div className="max-w-7xl mx-auto px-4 py-20 text-center">Loading...</div>;
  if (!question) return <div className="max-w-7xl mx-auto px-4 py-20 text-center">Question not found</div>;

  const category = categories.find(c => c.id === question.categoryId);

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="flex gap-8">
        <div className="flex flex-col items-center gap-4 pt-2">
          <Button variant="ghost" className="p-2" onClick={() => handleVote(question.id, 'question', 1, question.authorId)}>
            <ThumbsUp className="w-6 h-6" />
          </Button>
          <span className={cn('text-xl font-bold', theme === 'dark' ? 'text-white' : 'text-gray-900')}>{question.voteCount}</span>
          <Button variant="ghost" className="p-2" onClick={() => handleVote(question.id, 'question', -1, question.authorId)}>
            <ThumbsDown className="w-6 h-6" />
          </Button>
          <Button 
            variant="ghost" 
            className={cn('p-2', isBookmarked ? 'text-yellow-500' : 'text-gray-400')}
            onClick={handleBookmark}
          >
            <BookmarkIcon className={cn('w-6 h-6', isBookmarked && 'fill-current')} />
          </Button>
        </div>

        <div className="flex-1">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-4">
                {category && <Badge color={category.color}>{category.name}</Badge>}
                <span className="text-xs text-gray-400">•</span>
                <span className="text-xs text-gray-400">Asked {formatRelativeTime(question.createdAt)}</span>
              </div>
              <h1 className={cn('text-3xl font-bold mb-6', theme === 'dark' ? 'text-white' : 'text-gray-900')}>{question.title}</h1>
              
              <div className={cn('prose max-w-none mb-8', theme === 'dark' ? 'prose-invert' : 'text-gray-800')}>
                <ReactMarkdown>{question.body}</ReactMarkdown>
              </div>

              <div className="flex items-center justify-between py-4 border-t border-b border-gray-100">
                <div className="flex items-center gap-3">
                  <Avatar name={question.authorName} />
                  <div>
                    <p className={cn('text-sm font-bold', theme === 'dark' ? 'text-white' : 'text-gray-900')}>{question.authorName}</p>
                    <p className="text-xs text-gray-500">Author</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="sm" className="gap-2"><Share2 className="w-4 h-4" /> Share</Button>
                  <Button variant="ghost" size="sm" className="gap-2"><Flag className="w-4 h-4" /> Report</Button>
                  {user?.uid === question.authorId && (
                    <>
                      <Button variant="ghost" size="sm" className="gap-2"><Edit className="w-4 h-4" /> Edit</Button>
                      <Button variant="ghost" size="sm" className="gap-2 text-red-600 hover:bg-red-50"><Trash2 className="w-4 h-4" /> Delete</Button>
                    </>
                  )}
                </div>
              </div>
            </div>

            <CommentSection 
              targetId={question.id} 
              comments={comments[question.id] || []} 
              onComment={handleComment} 
              user={user}
              theme={theme}
            />

            <div className="mt-12">
              <h2 className={cn('text-xl font-bold mb-6', theme === 'dark' ? 'text-white' : 'text-gray-900')}>{answers.length} Answers</h2>
              <div className="space-y-8">
                {answers.map(ans => (
                  <div key={ans.id} className={cn('flex gap-6 pb-8 border-b border-gray-100 last:border-0', ans.isAccepted && 'bg-green-50/50 -mx-4 px-4 py-6 rounded-xl')}>
                    <div className="flex flex-col items-center gap-2 pt-1">
                      <Button variant="ghost" className="p-1.5" onClick={() => handleVote(ans.id, 'answer', 1, ans.authorId)}>
                        <ThumbsUp className="w-4 h-4" />
                      </Button>
                      <span className={cn('text-sm font-bold', theme === 'dark' ? 'text-white' : 'text-gray-900')}>{ans.voteCount}</span>
                      <Button variant="ghost" className="p-1.5" onClick={() => handleVote(ans.id, 'answer', -1, ans.authorId)}>
                        <ThumbsDown className="w-4 h-4" />
                      </Button>
                      {ans.isAccepted && <CheckCircle className="w-6 h-6 text-green-600 mt-2" />}
                      {user?.uid === question.authorId && !ans.isAccepted && (
                        <Button variant="ghost" className="p-1.5 text-gray-300 hover:text-green-600" onClick={() => handleAccept(ans.id, ans.authorId)}>
                          <CheckCircle className="w-6 h-6" />
                        </Button>
                      )}
                    </div>
                    
                    <div className="flex-1">
                      <div className={cn('prose max-w-none mb-4', theme === 'dark' ? 'prose-invert' : 'text-gray-800')}>
                        <ReactMarkdown>{ans.body}</ReactMarkdown>
                      </div>
                      
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-2">
                          <Avatar name={ans.authorName} size="sm" />
                          <span className={cn('text-sm font-medium', theme === 'dark' ? 'text-gray-300' : 'text-gray-700')}>{ans.authorName}</span>
                          <span className="text-xs text-gray-400">• {formatRelativeTime(ans.createdAt)}</span>
                        </div>
                      </div>

                      <CommentSection 
                        targetId={ans.id} 
                        comments={comments[ans.id] || []} 
                        onComment={handleComment} 
                        user={user}
                        theme={theme}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-12 pt-8 border-t border-gray-200">
              <h3 className={cn('text-lg font-bold mb-4', theme === 'dark' ? 'text-white' : 'text-gray-900')}>Your Answer</h3>
              {user ? (
                <form onSubmit={handlePostAnswer}>
                  <textarea 
                    className={cn(
                      'w-full p-4 border rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[200px]',
                      theme === 'dark' ? 'bg-zinc-800 border-zinc-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
                    )}
                    placeholder="Write your answer here (Markdown supported)..."
                    value={newAnswer}
                    onChange={(e) => setNewAnswer(e.target.value)}
                  />
                  <div className="mt-4 flex justify-end">
                    <Button type="submit" disabled={!newAnswer.trim()}>Post Answer</Button>
                  </div>
                </form>
              ) : (
                <div className={cn('p-8 rounded-xl text-center border border-dashed', theme === 'dark' ? 'bg-zinc-900 border-zinc-800' : 'bg-gray-50 border-gray-300')}>
                  <p className="text-gray-600">Please sign in to post an answer.</p>
                  <Button onClick={loginWithGoogle} className="mt-4">Sign In with Google</Button>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

const CommentSection = ({ targetId, comments, onComment, user, theme }: any) => {
  const [showInput, setShowInput] = useState(false);
  const [body, setBody] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!body.trim()) return;
    onComment(targetId, body);
    setBody('');
    setShowInput(false);
  };

  return (
    <div className={cn('border-t pt-4 mt-4', theme === 'dark' ? 'border-zinc-800' : 'border-gray-100')}>
      <div className="space-y-3 mb-4">
        {comments.map((comment: DoubtComment) => (
          <div key={comment.id} className={cn('text-sm border-b pb-2 last:border-0', theme === 'dark' ? 'border-zinc-800' : 'border-gray-50')}>
            <span className={cn(theme === 'dark' ? 'text-gray-300' : 'text-gray-700')}>{comment.body}</span>
            <span className="text-indigo-600 font-medium ml-2">— {comment.authorName}</span>
            <span className="text-gray-400 text-[10px] ml-2">{formatRelativeTime(comment.createdAt)}</span>
          </div>
        ))}
      </div>
      
      {user && (
        <>
          {!showInput ? (
            <button 
              onClick={() => setShowInput(true)}
              className="text-xs text-gray-400 hover:text-indigo-600 transition-colors"
            >
              Add a comment
            </button>
          ) : (
            <form onSubmit={handleSubmit} className="flex gap-2">
              <input 
                type="text"
                className={cn(
                  'flex-1 text-sm p-2 border rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500',
                  theme === 'dark' ? 'bg-zinc-800 border-zinc-700 text-white' : 'bg-white border-gray-200 text-gray-900'
                )}
                placeholder="Type your comment..."
                value={body}
                onChange={(e) => setBody(e.target.value)}
                autoFocus
              />
              <Button type="submit" size="sm">Add</Button>
              <Button type="button" variant="ghost" size="sm" onClick={() => setShowInput(false)}>Cancel</Button>
            </form>
          )}
        </>
      )}
    </div>
  );
};

const AskQuestion = ({ user, theme }: any) => {
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [tags, setTags] = useState('');
  const [categories, setCategories] = useState<Category[]>([]);
  const [isListening, setIsListening] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchCats = async () => {
      const data = await getCategories();
      setCategories(data);
    };
    fetchCats();
  }, []);

  const handleVoiceInput = () => {
    if (!('webkitSpeechRecognition' in window)) {
      alert('Speech recognition is not supported in this browser.');
      return;
    }

    const recognition = new (window as any).webkitSpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setBody(prev => prev + ' ' + transcript);
    };

    recognition.start();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !title.trim() || !body.trim() || !categoryId) return;

    const tagList = tags.split(',').map(t => t.trim()).filter(t => t !== '');
    
    const docRef = await createQuestion({
      title,
      body,
      categoryId,
      tags: tagList,
      authorId: user.uid,
      authorName: user.displayName,
    });
    
    navigate(`/questions/${docRef.id}`);
  };

  if (!user) return <div className="max-w-7xl mx-auto px-4 py-20 text-center">Please sign in to ask a question.</div>;

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="max-w-3xl mx-auto px-4 py-12"
    >
      <h1 className={cn('text-3xl font-bold mb-8', theme === 'dark' ? 'text-white' : 'text-gray-900')}>Ask a Question</h1>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <Card className={cn('p-6', theme === 'dark' ? 'bg-zinc-900 border-zinc-800' : 'bg-white')}>
          <div className="space-y-6">
            <div>
              <label className={cn('block text-sm font-bold mb-2', theme === 'dark' ? 'text-gray-200' : 'text-gray-700')}>Title</label>
              <p className="text-xs text-gray-500 mb-2">Be specific and imagine you’re asking a question to another person.</p>
              <div className="relative">
                <input 
                  type="text" 
                  maxLength={150}
                  className={cn(
                    'w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500',
                    theme === 'dark' ? 'bg-zinc-800 border-zinc-700 text-white' : 'bg-white border-gray-200 text-gray-900'
                  )}
                  placeholder="e.g. How do I find the derivative of sin(x)?"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-gray-400">
                  {title.length}/150
                </span>
              </div>
            </div>

            <div>
              <label className={cn('block text-sm font-bold mb-2', theme === 'dark' ? 'text-gray-200' : 'text-gray-700')}>Subject Category</label>
              <select 
                className={cn(
                  'w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500',
                  theme === 'dark' ? 'bg-zinc-800 border-zinc-700 text-white' : 'bg-white border-gray-200 text-gray-900'
                )}
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value)}
                required
              >
                <option value="">Select a subject...</option>
                {categories.map(cat => (
                  <option key={cat.id} value={cat.id}>{cat.name}</option>
                ))}
              </select>
            </div>

            <div>
              <div className="flex justify-between items-center mb-2">
                <label className={cn('block text-sm font-bold', theme === 'dark' ? 'text-gray-200' : 'text-gray-700')}>Body</label>
                <button 
                  type="button"
                  onClick={handleVoiceInput}
                  className={cn(
                    'flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full transition-colors',
                    isListening ? 'bg-red-100 text-red-600 animate-pulse' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  )}
                >
                  <Mic className="w-3 h-3" /> {isListening ? 'Listening...' : 'Voice Input'}
                </button>
              </div>
              <p className="text-xs text-gray-500 mb-2">Include all the information someone would need to answer your question.</p>
              <textarea 
                className={cn(
                  'w-full p-4 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[300px]',
                  theme === 'dark' ? 'bg-zinc-800 border-zinc-700 text-white' : 'bg-white border-gray-200 text-gray-900'
                )}
                placeholder="Describe your problem in detail..."
                value={body}
                onChange={(e) => setBody(e.target.value)}
                required
              />
            </div>

            <div>
              <label className={cn('block text-sm font-bold mb-2', theme === 'dark' ? 'text-gray-200' : 'text-gray-700')}>Tags</label>
              <p className="text-xs text-gray-500 mb-2">Add up to 5 tags to describe what your question is about (comma separated).</p>
              <input 
                type="text" 
                className={cn(
                  'w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500',
                  theme === 'dark' ? 'bg-zinc-800 border-zinc-700 text-white' : 'bg-white border-gray-200 text-gray-900'
                )}
                placeholder="e.g. calculus, trigonometry, math"
                value={tags}
                onChange={(e) => setTags(e.target.value)}
              />
            </div>
          </div>
        </Card>

        <div className="pt-4">
          <Button type="submit" size="lg" className="w-full shadow-xl shadow-indigo-500/20" disabled={!title.trim() || !body.trim() || !categoryId}>
            Post Question
          </Button>
        </div>
      </form>
    </motion.div>
  );
};

// --- Subjects Component ---

const Subjects = ({ theme }: { theme: string }) => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCats = async () => {
      const data = await getCategories();
      setCategories(data);
      setLoading(false);
    };
    fetchCats();
  }, []);

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'BookOpen': return <BookOpen className="w-6 h-6" />;
      case 'FlaskConical': return <FlaskConical className="w-6 h-6" />;
      case 'Languages': return <Languages className="w-6 h-6" />;
      case 'HistoryIcon': return <HistoryIcon className="w-6 h-6" />;
      case 'Code': return <Code className="w-6 h-6" />;
      case 'TrendingUp': return <TrendingUp className="w-6 h-6" />;
      case 'Globe': return <Globe className="w-6 h-6" />;
      case 'Search': return <Search className="w-6 h-6" />;
      default: return <BookOpen className="w-6 h-6" />;
    }
  };

  if (loading) return <div className="max-w-7xl mx-auto px-4 py-20 text-center">Loading subjects...</div>;

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="mb-12 text-center max-w-2xl mx-auto">
        <h1 className={cn('text-4xl font-black mb-4', theme === 'dark' ? 'text-white' : 'text-gray-900')}>Explore Subjects</h1>
        <p className="text-gray-500">Choose a subject to find relevant questions or ask your own in that category.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {categories.map((cat) => (
          <Link key={cat.id} to={`/?category=${cat.id}`}>
            <motion.div
              whileHover={{ y: -5 }}
              className={cn(
                'p-8 rounded-3xl border h-full flex flex-col transition-all group',
                theme === 'dark' ? 'bg-zinc-900 border-zinc-800 hover:border-indigo-500/50' : 'bg-white border-gray-100 hover:border-indigo-200 shadow-sm hover:shadow-xl'
              )}
            >
              <div className={cn(
                'w-14 h-14 rounded-2xl flex items-center justify-center mb-6 transition-transform group-hover:scale-110',
                `bg-${cat.color}-500/10 text-${cat.color}-500`
              )}>
                {getIcon(cat.icon)}
              </div>
              <h3 className={cn('text-xl font-bold mb-2', theme === 'dark' ? 'text-white' : 'text-gray-900')}>{cat.name}</h3>
              <p className="text-sm text-gray-500 mb-6 flex-1">{cat.description || 'Explore questions and answers in this category.'}</p>
              <div className="flex items-center text-xs font-bold text-indigo-600 gap-1 group-hover:gap-2 transition-all">
                View Questions <ChevronRight className="w-3 h-3" />
              </div>
            </motion.div>
          </Link>
        ))}
      </div>
    </div>
  );
};

const Profile = ({ user: currentUser, theme }: any) => {
  const { uid } = useParams();
  const targetUid = uid || currentUser?.uid;
  const [profile, setProfile] = useState<User | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [bookmarks, setBookmarks] = useState<Question[]>([]);
  const [activeTab, setActiveTab] = useState<'questions' | 'answers' | 'bookmarks'>('questions');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!targetUid) return;

    const fetchData = async () => {
      const userProfile = await getUserProfile(targetUid);
      setProfile(userProfile);

      // Fetch questions
      const q = getQuestions(undefined, 'newest', targetUid);
      const unsubscribeQ = onSnapshot(q, (snapshot) => {
        setQuestions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Question)));
      });

      // Fetch answers
      const a = getAnswers(undefined, targetUid);
      const unsubscribeA = onSnapshot(a, (snapshot) => {
        setAnswers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Answer)));
      });

      // Fetch bookmarks
      if (currentUser?.uid === targetUid) {
        const b = getBookmarks(targetUid);
        const unsubscribeB = onSnapshot(b, async (snapshot) => {
          const bookmarkDocs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Bookmark));
          const bookmarkedQuestions = await Promise.all(
            bookmarkDocs.map(async (bm) => {
              const qSnap = await getQuestion(bm.questionId);
              return qSnap;
            })
          );
          setBookmarks(bookmarkedQuestions.filter(q => q !== null) as Question[]);
        });
        return () => {
          unsubscribeQ();
          unsubscribeA();
          unsubscribeB();
        };
      }

      setLoading(false);
      return () => {
        unsubscribeQ();
        unsubscribeA();
      };
    };

    fetchData();
  }, [targetUid, currentUser]);

  if (loading && !profile) return <div className="max-w-7xl mx-auto px-4 py-20 text-center">Loading profile...</div>;
  if (!profile) return <div className="max-w-7xl mx-auto px-4 py-20 text-center">User not found</div>;

  const stats = [
    { label: 'Reputation', value: profile.reputation || 0, icon: Zap, color: 'text-yellow-500' },
    { label: 'Questions', value: questions.length, icon: MessageSquare, color: 'text-indigo-500' },
    { label: 'Answers', value: answers.length, icon: CheckCircle, color: 'text-green-500' },
    { label: 'Badges', value: profile.badges?.length || 0, icon: Award, color: 'text-purple-500' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Profile Info */}
        <div className="lg:col-span-1 space-y-6">
          <Card className={cn('p-6 text-center', theme === 'dark' ? 'bg-zinc-900 border-zinc-800' : 'bg-white')}>
            <div className="flex justify-center mb-4">
              <Avatar src={profile.avatarUrl} name={profile.username} size="lg" />
            </div>
            <h2 className={cn('text-xl font-bold', theme === 'dark' ? 'text-white' : 'text-gray-900')}>{profile.username}</h2>
            <p className="text-sm text-gray-500 mb-4">Member since {new Date(profile.createdAt).toLocaleDateString()}</p>
            <Badge color="blue" className="mb-6">{profile.level || 'Beginner'}</Badge>
            
            <div className="grid grid-cols-2 gap-4 pt-6 border-t border-gray-100">
              {stats.map(stat => (
                <div key={stat.label} className="text-center">
                  <div className="flex justify-center mb-1">
                    <stat.icon className={cn('w-4 h-4', stat.color)} />
                  </div>
                  <p className={cn('text-lg font-bold leading-none', theme === 'dark' ? 'text-white' : 'text-gray-900')}>{stat.value}</p>
                  <p className="text-[10px] uppercase tracking-wider text-gray-400 mt-1">{stat.label}</p>
                </div>
              ))}
            </div>
          </Card>

          <Card className={cn('p-6', theme === 'dark' ? 'bg-zinc-900 border-zinc-800' : 'bg-white')}>
            <h3 className={cn('font-bold mb-4', theme === 'dark' ? 'text-white' : 'text-gray-900')}>Badges</h3>
            <div className="flex flex-wrap gap-2">
              {profile.badges && profile.badges.length > 0 ? (
                profile.badges.map(badge => (
                  <div key={badge} className="flex items-center gap-1 bg-indigo-50 text-indigo-700 px-2 py-1 rounded-lg text-xs font-medium border border-indigo-100">
                    <Star className="w-3 h-3 fill-current" /> {badge}
                  </div>
                ))
              ) : (
                <p className="text-xs text-gray-400 italic">No badges earned yet.</p>
              )}
            </div>
          </Card>
        </div>

        {/* Activity Tabs */}
        <div className="lg:col-span-3">
          <div className="flex border-b border-gray-200 mb-6">
            <button 
              onClick={() => setActiveTab('questions')}
              className={cn('px-6 py-3 text-sm font-medium border-b-2 transition-colors', activeTab === 'questions' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-gray-500 hover:text-gray-700')}
            >
              Questions ({questions.length})
            </button>
            <button 
              onClick={() => setActiveTab('answers')}
              className={cn('px-6 py-3 text-sm font-medium border-b-2 transition-colors', activeTab === 'answers' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-gray-500 hover:text-gray-700')}
            >
              Answers ({answers.length})
            </button>
            {currentUser?.uid === targetUid && (
              <button 
                onClick={() => setActiveTab('bookmarks')}
                className={cn('px-6 py-3 text-sm font-medium border-b-2 transition-colors', activeTab === 'bookmarks' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-gray-500 hover:text-gray-700')}
              >
                Bookmarks ({bookmarks.length})
              </button>
            )}
          </div>

          <div className="space-y-4">
            {activeTab === 'questions' && (
              questions.length > 0 ? (
                questions.map(q => (
                  <Link key={q.id} to={`/questions/${q.id}`}>
                    <Card className={cn('p-4 hover:border-indigo-200 transition-colors mb-4', theme === 'dark' ? 'bg-zinc-900 border-zinc-800' : 'bg-white')}>
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className={cn('font-bold mb-1', theme === 'dark' ? 'text-white' : 'text-gray-900')}>{q.title}</h4>
                          <div className="flex items-center gap-3 text-xs text-gray-400">
                            <span>{q.voteCount} votes</span>
                            <span>•</span>
                            <span>{q.answerCount} answers</span>
                            <span>•</span>
                            <span>{formatRelativeTime(q.createdAt)}</span>
                          </div>
                        </div>
                        {q.isResolved && <CheckCircle className="w-5 h-5 text-green-500" />}
                      </div>
                    </Card>
                  </Link>
                ))
              ) : (
                <div className="text-center py-12 text-gray-400">No questions asked yet.</div>
              )
            )}

            {activeTab === 'answers' && (
              answers.length > 0 ? (
                answers.map(a => (
                  <Link key={a.id} to={`/questions/${a.questionId}`}>
                    <Card className={cn('p-4 hover:border-indigo-200 transition-colors mb-4', theme === 'dark' ? 'bg-zinc-900 border-zinc-800' : 'bg-white')}>
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <p className={cn('text-sm line-clamp-2 mb-2', theme === 'dark' ? 'text-gray-300' : 'text-gray-700')}>{a.body}</p>
                          <div className="flex items-center gap-3 text-xs text-gray-400">
                            <span className="text-indigo-600 font-medium">Re: {a.questionTitle}</span>
                            <span>•</span>
                            <span>{a.voteCount} votes</span>
                            <span>•</span>
                            <span>{formatRelativeTime(a.createdAt)}</span>
                          </div>
                        </div>
                        {a.isAccepted && <CheckCircle className="w-5 h-5 text-green-500" />}
                      </div>
                    </Card>
                  </Link>
                ))
              ) : (
                <div className="text-center py-12 text-gray-400">No answers given yet.</div>
              )
            )}

            {activeTab === 'bookmarks' && (
              bookmarks.length > 0 ? (
                bookmarks.map(q => (
                  <Link key={q.id} to={`/questions/${q.id}`}>
                    <Card className={cn('p-4 hover:border-indigo-200 transition-colors mb-4', theme === 'dark' ? 'bg-zinc-900 border-zinc-800' : 'bg-white')}>
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className={cn('font-bold mb-1', theme === 'dark' ? 'text-white' : 'text-gray-900')}>{q.title}</h4>
                          <div className="flex items-center gap-3 text-xs text-gray-400">
                            <span className="text-indigo-600 font-medium">{q.authorName}</span>
                            <span>•</span>
                            <span>{q.voteCount} votes</span>
                            <span>•</span>
                            <span>{q.answerCount} answers</span>
                          </div>
                        </div>
                        <BookmarkIcon className="w-5 h-5 text-yellow-500 fill-current" />
                      </div>
                    </Card>
                  </Link>
                ))
              ) : (
                <div className="text-center py-12 text-gray-400">No bookmarks yet.</div>
              )
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  useEffect(() => {
    const unsubscribe = subscribeToAuth((u) => {
      setUser(u);
      setLoading(false);
    });
    
    // Seed categories if empty
    const seed = async () => {
      const cats = await getDocs(collection(db, 'categories'));
      if (cats.empty) {
        const initialCategories = [
          { name: 'Mathematics', slug: 'math', color: 'blue', icon: 'BookOpen', description: 'Numbers, equations, and logic.' },
          { name: 'Science', slug: 'science', color: 'green', icon: 'FlaskConical', description: 'Physics, Chemistry, and Biology.' },
          { name: 'English', slug: 'english', color: 'purple', icon: 'Languages', description: 'Literature and grammar.' },
          { name: 'History', slug: 'history', color: 'amber', icon: 'HistoryIcon', description: 'Past events and civilizations.' },
          { name: 'Computer Science', slug: 'cs', color: 'pink', icon: 'Code', description: 'Programming and algorithms.' },
          { name: 'Economics', slug: 'economics', color: 'teal', icon: 'TrendingUp', description: 'Markets and finance.' },
          { name: 'Geography', slug: 'geography', color: 'orange', icon: 'Globe', description: 'Earth and its people.' },
          { name: 'General Knowledge', slug: 'general', color: 'gray', icon: 'Search', description: 'Miscellaneous topics.' },
        ];
        for (const cat of initialCategories) {
          await addDoc(collection(db, 'categories'), cat);
        }
      }
    };
    seed();

    return () => unsubscribe();
  }, []);

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  const handleLogin = async () => {
    try {
      await loginWithGoogle();
    } catch (err) {
      console.error(err);
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
    } catch (err) {
      console.error(err);
    }
  };

  if (loading) {
    return (
      <div className={cn('min-h-screen flex items-center justify-center', theme === 'dark' ? 'bg-zinc-950' : 'bg-gray-50')}>
        <div className="animate-pulse flex flex-col items-center gap-4">
          <div className="w-12 h-12 bg-indigo-600 rounded-xl" />
          <div className="h-4 w-32 bg-gray-200 rounded" />
        </div>
      </div>
    );
  }

  return (
    <Router>
      <div className={cn('min-h-screen font-sans transition-colors duration-300', theme === 'dark' ? 'bg-zinc-950 text-white' : 'bg-gray-50 text-gray-900')}>
        <Navbar user={user} onLogin={handleLogin} onLogout={handleLogout} theme={theme} onToggleTheme={toggleTheme} />
        
        <main>
          <Routes>
            <Route path="/" element={<Home user={user} theme={theme} />} />
            <Route path="/subjects" element={<Subjects theme={theme} />} />
            <Route path="/questions/:id" element={<QuestionDetail user={user} theme={theme} />} />
            <Route path="/ask" element={<AskQuestion user={user} theme={theme} />} />
            <Route path="/profile" element={<Profile user={user} theme={theme} />} />
            <Route path="/users/:uid" element={<Profile theme={theme} />} />
          </Routes>
        </main>

        <footer className={cn('py-12 mt-20 border-t', theme === 'dark' ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-gray-200')}>
          <div className="max-w-7xl mx-auto px-4 text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="w-6 h-6 bg-indigo-600 rounded flex items-center justify-center">
                <BookOpen className="w-4 h-4 text-white" />
              </div>
              <span className={cn('font-bold', theme === 'dark' ? 'text-white' : 'text-gray-900')}>Doubt Solver</span>
            </div>
            <p className="text-sm text-gray-500">© 2026 Doubt Solver. Empowering students through community knowledge.</p>
          </div>
        </footer>
      </div>
    </Router>
  );
}
